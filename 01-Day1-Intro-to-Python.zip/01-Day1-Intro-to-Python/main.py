print("Hello World")
print(5)